Econometrics - Session 3: Instrumental variables and two-stage least squares
Économétrie - Séance 3 : Variables instrumentales et doubles moindres carrés
Magistère in Development Economics, 3rd year, CERDI — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/econometrics/s03/

CONTENTS
  Goni-Abdoulkadiri_econometrics_s03_worksheet.pdf
  data/colonial_origins.dta
      Same data as Session 2, with settler mortality (logem4) and European
      settlement in 1900 (euro1900).

READINGS
  [Application] Acemoglu, D., Johnson, S. and Robinson, J. A. (2001). The
  Colonial Origins of Comparative Development: An Empirical Investigation.
  American Economic Review 91(5): 1369–1401.
  https://doi.org/10.1257/aer.91.5.1369
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press.
  https://doi.org/10.1515/9781400829828

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 3: Instrumental variables and
  two-stage least squares. Econometrics, Magistère in Development Economics,
  3rd year, CERDI — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/econometrics/s03/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
