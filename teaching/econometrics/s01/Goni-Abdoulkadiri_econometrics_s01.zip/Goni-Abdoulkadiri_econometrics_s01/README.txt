Econometrics - Session 1: Anatomy of OLS and interpretation
Économétrie - Séance 1 : Anatomie des MCO et interprétation
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/econometrics/s01/

CONTENTS
  Goni-Abdoulkadiri_econometrics_s01_worksheet.pdf
  data/card.dta
      Card (1995): 3,010 men of the NLS Young Men cohort, wages observed in
      1976.

READINGS
  [Application] Card, D. (1995). Using Geographic Variation in College
  Proximity to Estimate the Return to Schooling. In L. N. Christofides, E.
  K. Grant and R. Swidinsky (eds), Aspects of Labour Market Behaviour:
  Essays in Honour of John Vanderkamp, 201–222. University of Toronto Press
  (NBER Working Paper 4483). https://doi.org/10.3386/w4483
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press.
  https://doi.org/10.1515/9781400829828

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 1: Anatomy of OLS and
  interpretation. Econometrics, Magistère in Development Economics, 3rd
  year, School of Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/econometrics/s01/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
