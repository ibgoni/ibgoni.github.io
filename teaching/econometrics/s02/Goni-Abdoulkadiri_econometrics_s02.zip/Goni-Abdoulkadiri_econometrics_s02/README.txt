Econometrics - Session 2: Robust inference and diagnostics
Économétrie - Séance 2 : Inférence robuste et diagnostic
Magistère in Development Economics, 3rd year, CERDI — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/econometrics/s02/

CONTENTS
  Goni-Abdoulkadiri_econometrics_s02_worksheet.pdf
  data/colonial_origins.dta
      Acemoglu, Johnson and Robinson (2001): former colonies; the session
      uses the 64-country base sample (baseco = 1).

READINGS
  [Application] Acemoglu, D., Johnson, S. and Robinson, J. A. (2001). The
  Colonial Origins of Comparative Development: An Empirical Investigation.
  American Economic Review 91(5): 1369–1401.
  https://doi.org/10.1257/aer.91.5.1369
  [Method] White, H. (1980). A Heteroskedasticity-Consistent Covariance
  Matrix Estimator and a Direct Test for Heteroskedasticity. Econometrica
  48(4): 817–838. https://doi.org/10.2307/1912934
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press.
  https://doi.org/10.1515/9781400829828

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 2: Robust inference and diagnostics.
  Econometrics, Magistère in Development Economics, 3rd year, CERDI —
  Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/econometrics/s02/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
