Econometrics - Session 5: Dynamic panels and GMM
Économétrie - Séance 5 : Panel dynamique et GMM
Magistère in Development Economics, 3rd year, CERDI — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/econometrics/s05/

CONTENTS
  Goni-Abdoulkadiri_econometrics_s05_worksheet.pdf
  data/labor_supply.dta
      Ziliak (1997): the version of the Session 4 panel prepared for the
      dynamic model.

READINGS
  [Application] Ziliak, J. P. (1997). Efficient Estimation with Panel Data
  When Instruments Are Predetermined: An Empirical Comparison of
  Moment-Condition Estimators. Journal of Business & Economic Statistics
  15(4): 419–431. https://doi.org/10.1080/07350015.1997.10524720
  [Method] Arellano, M. and Bond, S. (1991). Some Tests of Specification for
  Panel Data: Monte Carlo Evidence and an Application to Employment
  Equations. Review of Economic Studies 58(2): 277–297.
  https://doi.org/10.2307/2297968
  [Method] Blundell, R. and Bond, S. (1998). Initial Conditions and Moment
  Restrictions in Dynamic Panel Data Models. Journal of Econometrics 87(1):
  115–143. https://doi.org/10.1016/S0304-4076(98)00009-8
  [Method] Roodman, D. (2009). A Note on the Theme of Too Many Instruments.
  Oxford Bulletin of Economics and Statistics 71(1): 135–158.
  https://doi.org/10.1111/j.1468-0084.2008.00542.x

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 5: Dynamic panels and GMM.
  Econometrics, Magistère in Development Economics, 3rd year, CERDI —
  Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/econometrics/s05/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
