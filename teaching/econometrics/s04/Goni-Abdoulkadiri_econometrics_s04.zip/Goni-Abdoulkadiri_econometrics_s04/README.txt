Econometrics - Session 4: Panel data and fixed effects
Économétrie - Séance 4 : Données de panel et effets fixes
Magistère in Development Economics, 3rd year, CERDI — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/econometrics/s04/

CONTENTS
  Goni-Abdoulkadiri_econometrics_s04_worksheet.pdf
  data/labor_supply.dta
      Ziliak (1997): balanced panel of 532 individuals observed from 1979 to
      1988 (5,320 observations).

READINGS
  [Application] Ziliak, J. P. (1997). Efficient Estimation with Panel Data
  When Instruments Are Predetermined: An Empirical Comparison of
  Moment-Condition Estimators. Journal of Business & Economic Statistics
  15(4): 419–431. https://doi.org/10.1080/07350015.1997.10524720
  [Method] Mundlak, Y. (1978). On the Pooling of Time Series and Cross
  Section Data. Econometrica 46(1): 69–85. https://doi.org/10.2307/1913646
  [Method] Wooldridge, J. M. (2010). Econometric Analysis of Cross Section
  and Panel Data, 2nd ed. MIT Press.

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 4: Panel data and fixed effects.
  Econometrics, Magistère in Development Economics, 3rd year, CERDI —
  Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/econometrics/s04/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
