Impact Evaluation - Session 4: Matching and selection on observables
Évaluation d’impact - Séance 4 : Appariement et sélection sur observables : population comparable, support commun et balance
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/impact-evaluation/s04/

CONTENTS
  Goni-Abdoulkadiri_impact-evaluation_s04_worksheet.pdf
  data/base_classe_bernard_et_al2008.dta
      Main application: simulated teaching data calibrated on the sample
      published by Bernard et al. (2008) — 2,532 households, 150 cooperative
      members. Not the authors’ data; not for research use.
  data/extension_cattaneo2010.dta
      Extension (exercise 6): the cattaneo2 birth-weight data distributed
      with Stata (also available with webuse cattaneo2).

READINGS
  [Application] Bernard, T., Taffesse, A. S. and Gabre-Madhin, E. (2008).
  Impact of Cooperatives on Smallholders’ Commercialization Behavior:
  Evidence from Ethiopia. Agricultural Economics 39(2): 147–161.
  https://doi.org/10.1111/j.1574-0862.2008.00324.x
  [Extension] Cattaneo, M. D. (2010). Efficient Semiparametric Estimation of
  Multi-valued Treatment Effects under Ignorability. Journal of Econometrics
  155(2): 138–154. https://doi.org/10.1016/j.jeconom.2009.09.023
  [Method] Rosenbaum, P. R. and Rubin, D. B. (1983). The Central Role of the
  Propensity Score in Observational Studies for Causal Effects. Biometrika
  70(1): 41–55. https://doi.org/10.1093/biomet/70.1.41

HOW TO CITE
  Abdoulkadiri, I. G. (2026). Session 4: Matching and selection on
  observables. Impact Evaluation, Magistère in Development Economics, 3rd
  year, School of Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/impact-evaluation/s04/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
