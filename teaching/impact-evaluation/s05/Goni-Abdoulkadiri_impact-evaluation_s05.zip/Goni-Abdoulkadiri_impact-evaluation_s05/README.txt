Impact Evaluation - Session 5: Instrumental variables and local effects
Évaluation d’impact - Séance 5 : Variables instrumentales (IV) : premier stade, exclusion, 2SLS et population des compliers
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/impact-evaluation/s05/

CONTENTS
  Goni-Abdoulkadiri_impact-evaluation_s05_worksheet.pdf
  data/extension_angrist_krueger1991.dta
      Extension (exercise 6): teaching extract of the Angrist and Krueger
      (1991) data on quarter of birth, schooling and earnings.

AUTHORS' REPLICATION DATA (not included, download from the source)
  Nunn_Wantchekon_AER_2011.dta  <https://doi.org/10.3886/E112479V1>
      Nunn and Wantchekon (2011), replication package. Main application
      (exercises 3–5): the authors’ file, used unmodified (21,822
      observations); the worksheet refers to it as
      article_principal_nunn_wantchekon2011.dta.

READINGS
  [Application] Nunn, N. and Wantchekon, L. (2011). The Slave Trade and the
  Origins of Mistrust in Africa. American Economic Review 101(7): 3221–3252.
  https://doi.org/10.1257/aer.101.7.3221
  [Extension] Angrist, J. D. and Krueger, A. B. (1991). Does Compulsory
  School Attendance Affect Schooling and Earnings? Quarterly Journal of
  Economics 106(4): 979–1014. https://doi.org/10.2307/2937954
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press,
  chapter 4. https://doi.org/10.1515/9781400829828

HOW TO CITE
  Abdoulkadiri, I. G. (2026). Session 5: Instrumental variables and local
  effects. Impact Evaluation, Magistère in Development Economics, 3rd year,
  School of Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/impact-evaluation/s05/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
