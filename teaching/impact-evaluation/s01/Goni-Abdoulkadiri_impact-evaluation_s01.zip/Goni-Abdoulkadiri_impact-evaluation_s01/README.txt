Impact Evaluation - Session 1: Randomized controlled trials
Évaluation d’impact - Séance 1 : Expériences aléatoires contrôlées (RCT) : assignation, intention de traiter et interférences
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/impact-evaluation/s01/

CONTENTS
  Goni-Abdoulkadiri_impact-evaluation_s01_worksheet.pdf
  data/extension_crepon2013.dta
      Extension (exercise 5): teaching extract for Crépon et al. (2013) —
      young job seekers, assignment, treated areas and randomization blocks.

AUTHORS' REPLICATION DATA (not included, download from the source)
  MozNatRes_Mozambique.dta  <https://doi.org/10.3886/E119785V1>
      Armand et al. (2020), replication package. Main application (exercises
      3–4): the authors’ file, used unmodified — 4,168 household-year
      observations in 206 communities.

READINGS
  [Application] Armand, A., Coutts, A., Vicente, P. C. and Vilela, I.
  (2020). Does Information Break the Political Resource Curse? Experimental
  Evidence from Mozambique. American Economic Review 110(11): 3431–3453.
  https://doi.org/10.1257/aer.20190842
  [Extension] Crépon, B., Duflo, E., Gurgand, M., Rathelot, R. and Zamora,
  P. (2013). Do Labor Market Policies Have Displacement Effects? Evidence
  from a Clustered Randomized Experiment. Quarterly Journal of Economics
  128(2): 531–580. https://doi.org/10.1093/qje/qjt001
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press,
  chapters 2 and 8. https://doi.org/10.1515/9781400829828

HOW TO CITE
  Abdoulkadiri, I. G. (2026). Session 1: Randomized controlled trials.
  Impact Evaluation, Magistère in Development Economics, 3rd year, School of
  Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/impact-evaluation/s01/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
