Impact Evaluation - Session 3: Difference-in-differences
Évaluation d’impact - Séance 3 : Doubles différences (DiD) : tendances parallèles, effets fixes et étude d’événement
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/impact-evaluation/s03/

CONTENTS
  Goni-Abdoulkadiri_impact-evaluation_s03_worksheet.pdf
  data/extension_autor2003.dta
      Extension (exercise 6): U.S. states adopting unjust-dismissal
      doctrines at different dates.

AUTHORS' REPLICATION DATA (not included, download from the source)
  qlfs.dta  <https://doi.org/10.3886/E113156V1>
      Hjort and Poulsen (2019), replication package. Exercises 3–5 use an
      extract of this file, saved as
      article_principal_hjort_poulsen2019_extrait_officiel.dta: keep eacode
      time connected treatment employed formal informal distance hoursworked
      q422more, then keep if time < 20103 & distance < 0.1 (464,958
      observations).

READINGS
  [Application] Hjort, J. and Poulsen, J. (2019). The Arrival of Fast
  Internet and Employment in Africa. American Economic Review 109(3):
  1032–1079. https://doi.org/10.1257/aer.20161385
  [Extension] Autor, D. H. (2003). Outsourcing at Will: The Contribution of
  Unjust Dismissal Doctrine to the Growth of Employment Outsourcing. Journal
  of Labor Economics 21(1): 1–42. https://doi.org/10.1086/344122

HOW TO CITE
  Abdoulkadiri, I. G. (2026). Session 3: Difference-in-differences. Impact
  Evaluation, Magistère in Development Economics, 3rd year, School of
  Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/impact-evaluation/s03/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
