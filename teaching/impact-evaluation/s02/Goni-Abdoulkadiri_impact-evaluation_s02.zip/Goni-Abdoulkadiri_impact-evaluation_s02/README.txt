Impact Evaluation - Session 2: Regression discontinuity
Évaluation d’impact - Séance 2 : Régression sur discontinuité (RDD) : identification au seuil et choix de la fenêtre d’estimation
Magistère in Development Economics, 3rd year, School of Economics — Université Clermont Auvergne, 2026–27

Author:  Ibrahim Goni Abdoulkadiri
Source:  https://ibgoni.github.io/teaching/impact-evaluation/s02/

CONTENTS
  Goni-Abdoulkadiri_impact-evaluation_s02_worksheet.pdf
  data/extension_lemieux_milligan2008.dta
      Extension (exercise 6): employment rates by age, census year and
      region (Quebec or rest of Canada), with cell sizes used as weights.

AUTHORS' REPLICATION DATA (not included, download from the source)
  hiv-figure2a.dta  <https://doi.org/10.3886/E113080V1>
      Anderson (2018), replication package. Exercise 3: observations used to
      draw Figure 2A.
  hiv-table1.dta  <https://doi.org/10.3886/E113080V1>
      Anderson (2018), replication package. Exercise 4: reproduces the first
      three columns of Table 1.

READINGS
  [Application] Anderson, S. (2018). Legal Origins and Female HIV. American
  Economic Review 108(6): 1407–1439. https://doi.org/10.1257/aer.20151047
  [Extension] Lemieux, T. and Milligan, K. (2008). Incentive Effects of
  Social Assistance: A Regression Discontinuity Approach. Journal of
  Econometrics 142(2): 807–828.
  https://doi.org/10.1016/j.jeconom.2007.05.014
  [Method] Angrist, J. D. and Pischke, J.-S. (2009). Mostly Harmless
  Econometrics: An Empiricist’s Companion. Princeton University Press,
  chapter 6. https://doi.org/10.1515/9781400829828

HOW TO CITE
  Goni Abdoulkadiri, I. (2026). Session 2: Regression discontinuity. Impact
  Evaluation, Magistère in Development Economics, 3rd year, School of
  Economics — Université Clermont Auvergne.
  https://ibgoni.github.io/teaching/impact-evaluation/s02/

LICENCE
  Worksheet (c) 2026 Ibrahim Goni Abdoulkadiri, released under Creative
  Commons Attribution-NonCommercial-NoDerivatives 4.0 International
  (https://creativecommons.org/licenses/by-nc-nd/4.0/): you may share it for
  non-commercial purposes, with attribution and without modification.
  Datasets remain the work of their original authors and are subject to
  their terms; see READINGS for the source of each application.

Worksheets are in French. Solutions are discussed in class and are not distributed.
